export const cities = [
  'Delhi','Mumbai','Bangalore','Hyderabad','Chennai',
  'Pune','Kolkata','Jaipur','Ahmedabad','Chandigarh'
];

export const properties = [
  {
    id: 'p1',
    city: 'Delhi',
    title: 'Sunny 2BHK near metro',
    price: 12000,
    broker: { name: 'Amit Sharma', phone: '+91-9876543210' },
    img: '/images/placeholder.svg',
    type: 'rent'
  },
  {
    id: 'p2',
    city: 'Mumbai',
    title: '1BHK studio in central area',
    price: 22000,
    broker: { name: 'Neha Patel', phone: '+91-9123456780' },
    img: '/images/placeholder.svg',
    type: 'rent'
  },
  {
    id: 'p3',
    city: 'Bangalore',
    title: 'Compact 1RK near tech parks',
    price: 15000,
    broker: { name: 'Ravi Kumar', phone: '+91-9988776655' },
    img: '/images/placeholder.svg',
    type: 'rent'
  }
];
