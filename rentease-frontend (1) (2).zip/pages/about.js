import Navbar from '../components/Navbar'
import Footer from '../components/Footer'

export default function About() {
  return (
    <>
      <Navbar />
      <main className="max-w-4xl mx-auto px-4 py-12">
        <h1 className="text-3xl font-bold">About RentEase</h1>
        <p className="mt-4 text-gray-600">RentEase is a modern frontend demo for property discovery. Our mission is to make searching and renting property simple, fast and delightful.</p>
      </main>
      <Footer />
    </>
  )
}
