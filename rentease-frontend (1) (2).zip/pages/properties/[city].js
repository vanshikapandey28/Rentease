import { useRouter } from 'next/router'
import Navbar from '../../components/Navbar'
import Footer from '../../components/Footer'
import PropertyCard from '../../components/PropertyCard'
import { properties } from '../../data/sampleData'

export default function CityPage() {
  const router = useRouter()
  const { city } = router.query
  const cityProps = (properties || []).filter(p => p.city?.toLowerCase() === (city || '').toLowerCase())

  return (
    <>
      <Navbar />
      <main className="max-w-6xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold">Properties in {city}</h1>
        <p className="text-sm text-gray-600 mt-1">Filter by price and contact brokers directly.</p>

        <div className="mt-6 grid md:grid-cols-2 gap-4">
          {cityProps.length ? cityProps.map(p => <PropertyCard key={p.id} p={p} />) : <div className="text-gray-600">No properties in sample data for this city yet.</div>}
        </div>
      </main>
      <Footer />
    </>
  )
}
