import Navbar from '../../components/Navbar'
import Footer from '../../components/Footer'
import StudentPropertyCard from '../../components/StudentPropertyCard'

const sampleStudent = [
  {id:'s1', title:'PG near college', price:4500, img:'/images/placeholder.svg'},
  {id:'s2', title:'Shared flat for students', price:6000, img:'/images/placeholder.svg'}
]

export default function Student() {
  return (
    <>
      <Navbar />
      <main className="max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold">Student PGs & Monthly Flats</h1>
        <p className="text-sm text-gray-600 mt-1">Monthly payment options available.</p>

        <div className="mt-6 grid md:grid-cols-2 gap-4">
          {sampleStudent.map(s => <StudentPropertyCard key={s.id} p={s} />)}
        </div>
      </main>
      <Footer />
    </>
  )
}
