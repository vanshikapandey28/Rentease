import Navbar from '../components/Navbar'
import Footer from '../components/Footer'
import CityCard from '../components/CityCard'
import PropertyCard from '../components/PropertyCard'
import LoanCard from '../components/LoanCard'
import { cities } from '../data/sampleData'

const sampleProperties = [
  { id: 'x1', title: 'Cozy 1BHK', price: 9000, broker: {name:'Rohit', phone:'+91-9000000000'}, img:'/images/placeholder.svg' },
  { id: 'x2', title: 'Modern 2BHK', price: 18000, broker: {name:'Sonia', phone:'+91-9111111111'}, img:'/images/placeholder.svg' }
]

export default function Home() {
  return (
    <>
      <Navbar />
      <main className="max-w-6xl mx-auto px-4 py-8">
        <section className="rentease-hero rounded-2xl p-8 mb-8">
          <h1 className="text-3xl font-bold">Find your next home with <span className="text-renteaseYellow">RentEase</span></h1>
          <p className="mt-2 text-gray-600">Search properties, hire brokers, find student PGs and apply for loans — all in one place.</p>

          <div className="mt-6">
            <input placeholder="Search city, property or broker" className="w-full p-3 rounded-full border" />
          </div>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-4">Popular Cities</h2>
          <div className="grid md:grid-cols-3 gap-4">
            {cities.map((c)=> <CityCard key={c} city={c} />)}
          </div>
        </section>

        <section className="mt-8">
          <h2 className="text-xl font-semibold mb-4">Highlighted Properties</h2>
          <div className="grid md:grid-cols-2 gap-4">
            {sampleProperties.map(p=> <PropertyCard key={p.id} p={p} />)}
          </div>
        </section>

        <section className="mt-8">
          <h2 className="text-xl font-semibold mb-4">Home Loan</h2>
          <LoanCard />
        </section>
      </main>
      <Footer />
    </>
  )
}
