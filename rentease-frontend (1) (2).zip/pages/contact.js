import Navbar from '../components/Navbar'
import Footer from '../components/Footer'

export default function Contact() {
  return (
    <>
      <Navbar />
      <main className="max-w-3xl mx-auto px-4 py-12">
        <h1 className="text-2xl font-bold">Contact Us</h1>
        <p className="mt-2 text-gray-600">Fill the form and we will get back to you.</p>

        <form className="mt-4 space-y-3 card">
          <input placeholder="Name" className="w-full p-2 border rounded-md" />
          <input placeholder="Email" className="w-full p-2 border rounded-md" />
          <textarea placeholder="Message" className="w-full p-2 border rounded-md" />
          <button className="px-4 py-2 rounded-md bg-renteaseYellow">Send</button>
        </form>
      </main>
      <Footer />
    </>
  )
}
