import Navbar from '../../components/Navbar'
import Footer from '../../components/Footer'
import BrokerCard from '../../components/BrokerCard'

const brokers = [
  { id: 'b1', name: 'Amit Sharma', phone: '+91-9876543210', cities: ['Delhi','Noida'] },
  { id: 'b2', name: 'Neha Patel', phone: '+91-9123456780', cities: ['Mumbai'] }
]

export default function Brokers() {
  return (
    <>
      <Navbar />
      <main className="max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold">Brokers</h1>
        <div className="mt-4 grid md:grid-cols-2 gap-4">
          {brokers.map(b => <BrokerCard key={b.id} b={b} />)}
        </div>
      </main>
      <Footer />
    </>
  )
}
