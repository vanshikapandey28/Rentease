import { useRouter } from 'next/router'
import Navbar from '../components/Navbar'

export default function Login() {
  const router = useRouter()
  const handleSubmit = (e) => {
    e.preventDefault()
    // NOTE: Frontend-only mock login; replace with real auth later.
    router.push('/')
  }
  return (
    <>
      <Navbar />
      <main className="max-w-md mx-auto px-4 py-16">
        <div className="card">
          <h2 className="text-2xl font-semibold">Welcome back</h2>
          <p className="text-sm text-gray-600 mt-1">Sign in to continue to RentEase</p>
          <form onSubmit={handleSubmit} className="mt-4 space-y-3">
            <input placeholder="Email" className="w-full p-2 border rounded-md" />
            <input placeholder="Password" type="password" className="w-full p-2 border rounded-md" />
            <button className="w-full py-2 rounded-md bg-renteaseYellow">Sign in</button>
          </form>
        </div>
      </main>
    </>
  )
}
