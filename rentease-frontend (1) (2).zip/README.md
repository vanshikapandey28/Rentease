# RentEase - Frontend Scaffold

This is a frontend-only scaffold for RentEase built with Next.js (pages), Tailwind CSS and Framer Motion.
It includes sample pages, components and dummy data so you can run it locally.

## Quick start

1. Install dependencies:
   ```
   npm install
   ```

2. Run dev server:
   ```
   npm run dev
   ```
   Open http://localhost:3000

This project is purely frontend (no backend). Your backend developer can connect APIs to the components later.
