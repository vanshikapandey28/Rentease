export default function LoanCard() {
  return (
    <div className="card">
      <h3 className="font-semibold">Apply for Home Loan</h3>
      <p className="text-sm text-gray-600">Quick pre-approval for home loans. (Frontend demo)</p>
      <form className="mt-3 space-y-2">
        <input placeholder="Full name" className="w-full p-2 border rounded-md" />
        <input placeholder="Loan amount (₹)" className="w-full p-2 border rounded-md" />
        <div className="flex gap-2">
          <button className="px-3 py-2 rounded-md bg-renteaseYellow">Apply</button>
        </div>
      </form>
    </div>
  )
}
