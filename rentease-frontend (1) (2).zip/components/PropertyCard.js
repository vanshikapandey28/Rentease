export default function PropertyCard({p}) {
  return (
    <div className="card">
      <img src={p.img} alt={p.title} className="w-full h-40 object-cover rounded-lg" />
      <div className="mt-3">
        <h4 className="font-semibold">{p.title}</h4>
        <p className="text-sm text-gray-600">₹{p.price} / month</p>
        <p className="text-sm mt-2">Broker: {p.broker.name} — {p.broker.phone}</p>
        <div className="mt-3 flex gap-2">
          <button className="px-3 py-1 rounded-md border">Contact Broker</button>
          <button className="px-3 py-1 rounded-md bg-renteaseYellow">Hire Broker</button>
        </div>
      </div>
    </div>
  )
}
