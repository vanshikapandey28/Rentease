export default function BrokerCard({b}) {
  return (
    <div className="card">
      <h4 className="font-semibold">{b.name}</h4>
      <p className="text-sm text-gray-600">Phone: {b.phone}</p>
      <p className="text-sm">Cities: {b.cities?.join(', ')}</p>
      <div className="mt-3">
        <button className="px-3 py-1 rounded-md bg-renteaseYellow">Hire</button>
      </div>
    </div>
  )
}
