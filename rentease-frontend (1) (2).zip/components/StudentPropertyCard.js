export default function StudentPropertyCard({p}) {
  return (
    <div className="card">
      <img src={p.img} alt={p.title} className="w-full h-36 object-cover rounded-md" />
      <div className="mt-2">
        <h4 className="font-semibold">{p.title}</h4>
        <p className="text-sm">Monthly: ₹{p.price}</p>
        <div className="mt-2">
          <button className="px-3 py-1 rounded-md bg-renteaseYellow">Pay Monthly</button>
        </div>
      </div>
    </div>
  )
}
