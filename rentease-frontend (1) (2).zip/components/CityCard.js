import Link from 'next/link'
export default function CityCard({city}) {
  return (
    <Link href={`/properties/${encodeURIComponent(city)}`}>
      <a className="card hover:shadow-xl transition p-4 flex items-center justify-between">
        <div>
          <h3 className="font-semibold">{city}</h3>
          <p className="text-sm text-gray-500">Explore properties in {city}</p>
        </div>
        <img src="/images/placeholder.svg" alt={city} className="w-24 h-16 object-cover rounded-md"/>
      </a>
    </Link>
  )
}
